SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[COM_ShoppingCartCouponCode](
	[ShoppingCartCouponCodeID] [int] IDENTITY(1,1) NOT NULL,
	[ShoppingCartID] [int] NOT NULL,
	[CouponCode] [nvarchar](200) NOT NULL,
 CONSTRAINT [PK_COM_ShoppingCartCouponCode] PRIMARY KEY CLUSTERED 
(
	[ShoppingCartCouponCodeID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_COM_ShoppingCartCouponCode_ShoppingCartID] ON [dbo].[COM_ShoppingCartCouponCode]
(
	[ShoppingCartID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[COM_ShoppingCartCouponCode] ADD  CONSTRAINT [DEFAULT_COM_ShoppingCartCouponCode_ShoppingCartID]  DEFAULT ((0)) FOR [ShoppingCartID]
GO
ALTER TABLE [dbo].[COM_ShoppingCartCouponCode] ADD  CONSTRAINT [DEFAULT_COM_ShoppingCartCouponCode_CouponCode]  DEFAULT (N'') FOR [CouponCode]
GO
ALTER TABLE [dbo].[COM_ShoppingCartCouponCode]  WITH CHECK ADD  CONSTRAINT [FK_COM_ShoppingCartCouponCode_ShoppingCartID_COM_ShoppingCart] FOREIGN KEY([ShoppingCartID])
REFERENCES [dbo].[COM_ShoppingCart] ([ShoppingCartID])
GO
ALTER TABLE [dbo].[COM_ShoppingCartCouponCode] CHECK CONSTRAINT [FK_COM_ShoppingCartCouponCode_ShoppingCartID_COM_ShoppingCart]
GO
