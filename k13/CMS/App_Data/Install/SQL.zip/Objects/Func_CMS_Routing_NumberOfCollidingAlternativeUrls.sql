SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [Func_CMS_Routing_NumberOfCollidingAlternativeUrls](@path nvarchar(2000), @siteId int)
		RETURNS int
		AS 
		BEGIN
			IF LEN(@path) > 400
			BEGIN
				RETURN 0
			END
			DECLARE @rowcount int
			SELECT @rowcount = COUNT(*) 
				FROM CMS_AlternativeUrl 
				WHERE AlternativeUrlUrl = @path and AlternativeUrlSiteID = @siteId
			RETURN @rowcount
		END
GO
