SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CMS_PageFormerUrlPath](
	[PageFormerUrlPathID] [int] IDENTITY(1,1) NOT NULL,
	[PageFormerUrlPathUrlPath] [nvarchar](2000) NOT NULL,
	[PageFormerUrlPathUrlPathHash] [nvarchar](64) NOT NULL,
	[PageFormerUrlPathCulture] [nvarchar](50) NOT NULL,
	[PageFormerUrlPathNodeID] [int] NOT NULL,
	[PageFormerUrlPathSiteID] [int] NOT NULL,
	[PageFormerUrlPathLastModified] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_CMS_PageFormerUrlPath] PRIMARY KEY CLUSTERED 
(
	[PageFormerUrlPathID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_PageFormerUrlPath_PageFormerUrlPathNodeID] ON [dbo].[CMS_PageFormerUrlPath]
(
	[PageFormerUrlPathNodeID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_PageFormerUrlPath_PageFormerUrlPathSiteID] ON [dbo].[CMS_PageFormerUrlPath]
(
	[PageFormerUrlPathSiteID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
SET ANSI_PADDING ON
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_CMS_PageFormerUrlPath_UrlPathHash_Culture_SiteID] ON [dbo].[CMS_PageFormerUrlPath]
(
	[PageFormerUrlPathUrlPathHash] ASC,
	[PageFormerUrlPathCulture] ASC,
	[PageFormerUrlPathSiteID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[CMS_PageFormerUrlPath] ADD  CONSTRAINT [DEFAULT_CMS_PageFormerUrlPath_PageFormerUrlPathUrlPath]  DEFAULT (N'') FOR [PageFormerUrlPathUrlPath]
GO
ALTER TABLE [dbo].[CMS_PageFormerUrlPath] ADD  CONSTRAINT [DEFAULT_CMS_PageFormerUrlPath_PageFormerUrlPathUrlPathHash]  DEFAULT (N'') FOR [PageFormerUrlPathUrlPathHash]
GO
ALTER TABLE [dbo].[CMS_PageFormerUrlPath] ADD  CONSTRAINT [DEFAULT_CMS_PageFormerUrlPath_PageFormerUrlPathCulture]  DEFAULT (N'') FOR [PageFormerUrlPathCulture]
GO
ALTER TABLE [dbo].[CMS_PageFormerUrlPath] ADD  CONSTRAINT [DEFAULT_CMS_PageFormerUrlPath_PageFormerUrlPathNodeID]  DEFAULT ((0)) FOR [PageFormerUrlPathNodeID]
GO
ALTER TABLE [dbo].[CMS_PageFormerUrlPath] ADD  CONSTRAINT [DEFAULT_CMS_PageFormerUrlPath_PageFormerUrlPathSiteID]  DEFAULT ((0)) FOR [PageFormerUrlPathSiteID]
GO
ALTER TABLE [dbo].[CMS_PageFormerUrlPath] ADD  CONSTRAINT [DEFAULT_CMS_PageFormerUrlPath_PageFormerUrlPathLastModified]  DEFAULT ('1/1/0001 12:00:00 AM') FOR [PageFormerUrlPathLastModified]
GO
ALTER TABLE [dbo].[CMS_PageFormerUrlPath]  WITH CHECK ADD  CONSTRAINT [FK_CMS_PageFormerUrlPath_PageFormerUrlPathNodeID_CMS_Tree] FOREIGN KEY([PageFormerUrlPathNodeID])
REFERENCES [dbo].[CMS_Tree] ([NodeID])
GO
ALTER TABLE [dbo].[CMS_PageFormerUrlPath] CHECK CONSTRAINT [FK_CMS_PageFormerUrlPath_PageFormerUrlPathNodeID_CMS_Tree]
GO
ALTER TABLE [dbo].[CMS_PageFormerUrlPath]  WITH CHECK ADD  CONSTRAINT [FK_CMS_PageFormerUrlPath_PageFormerUrlPathSiteID_CMS_Site] FOREIGN KEY([PageFormerUrlPathSiteID])
REFERENCES [dbo].[CMS_Site] ([SiteID])
GO
ALTER TABLE [dbo].[CMS_PageFormerUrlPath] CHECK CONSTRAINT [FK_CMS_PageFormerUrlPath_PageFormerUrlPathSiteID_CMS_Site]
GO
