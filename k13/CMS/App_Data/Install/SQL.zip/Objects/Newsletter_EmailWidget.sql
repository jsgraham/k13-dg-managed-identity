SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Newsletter_EmailWidget](
	[EmailWidgetID] [int] IDENTITY(1,1) NOT NULL,
	[EmailWidgetGuid] [uniqueidentifier] NOT NULL,
	[EmailWidgetLastModified] [datetime2](7) NOT NULL,
	[EmailWidgetDisplayName] [nvarchar](250) NOT NULL,
	[EmailWidgetName] [nvarchar](250) NOT NULL,
	[EmailWidgetDescription] [nvarchar](max) NULL,
	[EmailWidgetCode] [nvarchar](max) NULL,
	[EmailWidgetSiteID] [int] NOT NULL,
	[EmailWidgetThumbnailGUID] [uniqueidentifier] NULL,
	[EmailWidgetIconCssClass] [nvarchar](200) NULL,
	[EmailWidgetProperties] [nvarchar](max) NULL,
 CONSTRAINT [PK_Newsletter_EmailWidget] PRIMARY KEY CLUSTERED 
(
	[EmailWidgetID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_Newsletter_EmailWidget_EmailWidgetSiteID] ON [dbo].[Newsletter_EmailWidget]
(
	[EmailWidgetSiteID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[Newsletter_EmailWidget] ADD  CONSTRAINT [DEFAULT_Newsletter_EmailWidget_EmailWidgetGuid]  DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [EmailWidgetGuid]
GO
ALTER TABLE [dbo].[Newsletter_EmailWidget] ADD  CONSTRAINT [DEFAULT_Newsletter_EmailWidget_EmailWidgetLastModified]  DEFAULT ('1/1/0001 12:00:00 AM') FOR [EmailWidgetLastModified]
GO
ALTER TABLE [dbo].[Newsletter_EmailWidget] ADD  CONSTRAINT [DEFAULT_Newsletter_EmailWidget_EmailWidgetDisplayName]  DEFAULT (N'') FOR [EmailWidgetDisplayName]
GO
ALTER TABLE [dbo].[Newsletter_EmailWidget] ADD  CONSTRAINT [DEFAULT_Newsletter_EmailWidget_EmailWidgetName]  DEFAULT (N'') FOR [EmailWidgetName]
GO
ALTER TABLE [dbo].[Newsletter_EmailWidget] ADD  CONSTRAINT [DEFAULT_Newsletter_EmailWidget_EmailWidgetSiteID]  DEFAULT ((0)) FOR [EmailWidgetSiteID]
GO
ALTER TABLE [dbo].[Newsletter_EmailWidget] ADD  CONSTRAINT [DEFAULT_Newsletter_EmailWidget_EmailWidgetIconCssClass]  DEFAULT (N'icon-cogwheel-square') FOR [EmailWidgetIconCssClass]
GO
ALTER TABLE [dbo].[Newsletter_EmailWidget]  WITH CHECK ADD  CONSTRAINT [FK_Newsletter_EmailWidget_EmailWidgetSiteID_CMS_Site] FOREIGN KEY([EmailWidgetSiteID])
REFERENCES [dbo].[CMS_Site] ([SiteID])
GO
ALTER TABLE [dbo].[Newsletter_EmailWidget] CHECK CONSTRAINT [FK_Newsletter_EmailWidget_EmailWidgetSiteID_CMS_Site]
GO
